# RemoteMonitoringSystem
Demo for a outdoor display remote monitoring system only collect temperature data from different parts based on Particle Electron.

BOM:

1. x1 Particle Electron kit

2. x1 DS18B20 temperature sensor TO-92 package

3. x1 DS18B20 temperature sensor probe

4. x1 4.7k omh resister

5. x1 bread board

6. wires
